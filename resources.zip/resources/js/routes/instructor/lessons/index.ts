import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/instructor/lessons/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorLessonController::create
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\InstructorLessonController::store
 * @see app/Http/Controllers/InstructorLessonController.php:32
 * @route '/instructor/lessons'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/instructor/lessons',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorLessonController::store
 * @see app/Http/Controllers/InstructorLessonController.php:32
 * @route '/instructor/lessons'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorLessonController::store
 * @see app/Http/Controllers/InstructorLessonController.php:32
 * @route '/instructor/lessons'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorLessonController::store
 * @see app/Http/Controllers/InstructorLessonController.php:32
 * @route '/instructor/lessons'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorLessonController::store
 * @see app/Http/Controllers/InstructorLessonController.php:32
 * @route '/instructor/lessons'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
export const edit = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/instructor/lessons/{lesson}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
edit.url = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: args.lesson,
                }

    return edit.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
edit.get = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
edit.head = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
    const editForm = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
        editForm.get = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorLessonController::edit
 * @see app/Http/Controllers/InstructorLessonController.php:0
 * @route '/instructor/lessons/{lesson}/edit'
 */
        editForm.head = (args: { lesson: string | number } | [lesson: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
export const update = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/instructor/lessons/{lesson}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
update.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return update.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
update.put = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
update.patch = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
    const updateForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
        updateForm.put = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\InstructorLessonController::update
 * @see app/Http/Controllers/InstructorLessonController.php:62
 * @route '/instructor/lessons/{lesson}'
 */
        updateForm.patch = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\InstructorLessonController::destroy
 * @see app/Http/Controllers/InstructorLessonController.php:93
 * @route '/instructor/lessons/{lesson}'
 */
export const destroy = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/instructor/lessons/{lesson}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\InstructorLessonController::destroy
 * @see app/Http/Controllers/InstructorLessonController.php:93
 * @route '/instructor/lessons/{lesson}'
 */
destroy.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return destroy.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorLessonController::destroy
 * @see app/Http/Controllers/InstructorLessonController.php:93
 * @route '/instructor/lessons/{lesson}'
 */
destroy.delete = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\InstructorLessonController::destroy
 * @see app/Http/Controllers/InstructorLessonController.php:93
 * @route '/instructor/lessons/{lesson}'
 */
    const destroyForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorLessonController::destroy
 * @see app/Http/Controllers/InstructorLessonController.php:93
 * @route '/instructor/lessons/{lesson}'
 */
        destroyForm.delete = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\InstructorLessonController::upload_resource
 * @see app/Http/Controllers/InstructorLessonController.php:107
 * @route '/instructor/lessons/{lesson}/upload-resource'
 */
export const upload_resource = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload_resource.url(args, options),
    method: 'post',
})

upload_resource.definition = {
    methods: ["post"],
    url: '/instructor/lessons/{lesson}/upload-resource',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorLessonController::upload_resource
 * @see app/Http/Controllers/InstructorLessonController.php:107
 * @route '/instructor/lessons/{lesson}/upload-resource'
 */
upload_resource.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return upload_resource.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorLessonController::upload_resource
 * @see app/Http/Controllers/InstructorLessonController.php:107
 * @route '/instructor/lessons/{lesson}/upload-resource'
 */
upload_resource.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload_resource.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorLessonController::upload_resource
 * @see app/Http/Controllers/InstructorLessonController.php:107
 * @route '/instructor/lessons/{lesson}/upload-resource'
 */
    const upload_resourceForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload_resource.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorLessonController::upload_resource
 * @see app/Http/Controllers/InstructorLessonController.php:107
 * @route '/instructor/lessons/{lesson}/upload-resource'
 */
        upload_resourceForm.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload_resource.url(args, options),
            method: 'post',
        })
    
    upload_resource.form = upload_resourceForm
const lessons = {
    create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
upload_resource: Object.assign(upload_resource, upload_resource),
}

export default lessons