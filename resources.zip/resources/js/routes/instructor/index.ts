import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import courses from './courses'
import sales from './sales'
import lessons from './lessons'
import quizzes from './quizzes'
import discussions from './discussions'
/**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/instructor/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorController::dashboard
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\ChunkUploadController::upload_chunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
export const upload_chunk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload_chunk.url(options),
    method: 'post',
})

upload_chunk.definition = {
    methods: ["post"],
    url: '/instructor/upload-chunk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::upload_chunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
upload_chunk.url = (options?: RouteQueryOptions) => {
    return upload_chunk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::upload_chunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
upload_chunk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upload_chunk.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::upload_chunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
    const upload_chunkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upload_chunk.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::upload_chunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
        upload_chunkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upload_chunk.url(options),
            method: 'post',
        })
    
    upload_chunk.form = upload_chunkForm
/**
* @see \App\Http\Controllers\ChunkUploadController::finish_upload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
export const finish_upload = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish_upload.url(args, options),
    method: 'post',
})

finish_upload.definition = {
    methods: ["post"],
    url: '/instructor/lessons/{lesson}/finish-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::finish_upload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
finish_upload.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return finish_upload.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::finish_upload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
finish_upload.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish_upload.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::finish_upload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
    const finish_uploadForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: finish_upload.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::finish_upload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
        finish_uploadForm.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: finish_upload.url(args, options),
            method: 'post',
        })
    
    finish_upload.form = finish_uploadForm
/**
* @see \App\Http\Controllers\ChunkUploadController::finish_course_preview_upload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
export const finish_course_preview_upload = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish_course_preview_upload.url(args, options),
    method: 'post',
})

finish_course_preview_upload.definition = {
    methods: ["post"],
    url: '/instructor/courses/{course}/finish-preview-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::finish_course_preview_upload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
finish_course_preview_upload.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return finish_course_preview_upload.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::finish_course_preview_upload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
finish_course_preview_upload.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finish_course_preview_upload.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::finish_course_preview_upload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
    const finish_course_preview_uploadForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: finish_course_preview_upload.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::finish_course_preview_upload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
        finish_course_preview_uploadForm.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: finish_course_preview_upload.url(args, options),
            method: 'post',
        })
    
    finish_course_preview_upload.form = finish_course_preview_uploadForm
const instructor = {
    dashboard: Object.assign(dashboard, dashboard),
courses: Object.assign(courses, courses),
sales: Object.assign(sales, sales),
lessons: Object.assign(lessons, lessons),
upload_chunk: Object.assign(upload_chunk, upload_chunk),
finish_upload: Object.assign(finish_upload, finish_upload),
finish_course_preview_upload: Object.assign(finish_course_preview_upload, finish_course_preview_upload),
quizzes: Object.assign(quizzes, quizzes),
discussions: Object.assign(discussions, discussions),
}

export default instructor