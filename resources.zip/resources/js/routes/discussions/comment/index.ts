import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\DiscussionController::add
 * @see app/Http/Controllers/DiscussionController.php:97
 * @route '/discussions/{discussion}/comments'
 */
export const add = (args: { discussion: number | { id: number } } | [discussion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

add.definition = {
    methods: ["post"],
    url: '/discussions/{discussion}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\DiscussionController::add
 * @see app/Http/Controllers/DiscussionController.php:97
 * @route '/discussions/{discussion}/comments'
 */
add.url = (args: { discussion: number | { id: number } } | [discussion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { discussion: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { discussion: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    discussion: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        discussion: typeof args.discussion === 'object'
                ? args.discussion.id
                : args.discussion,
                }

    return add.definition.url
            .replace('{discussion}', parsedArgs.discussion.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\DiscussionController::add
 * @see app/Http/Controllers/DiscussionController.php:97
 * @route '/discussions/{discussion}/comments'
 */
add.post = (args: { discussion: number | { id: number } } | [discussion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: add.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\DiscussionController::add
 * @see app/Http/Controllers/DiscussionController.php:97
 * @route '/discussions/{discussion}/comments'
 */
    const addForm = (args: { discussion: number | { id: number } } | [discussion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: add.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\DiscussionController::add
 * @see app/Http/Controllers/DiscussionController.php:97
 * @route '/discussions/{discussion}/comments'
 */
        addForm.post = (args: { discussion: number | { id: number } } | [discussion: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: add.url(args, options),
            method: 'post',
        })
    
    add.form = addForm
const comment = {
    add: Object.assign(add, add),
}

export default comment