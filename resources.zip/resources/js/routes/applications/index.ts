import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/apply-instructor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorApplicationController::create
 * @see app/Http/Controllers/InstructorApplicationController.php:25
 * @route '/apply-instructor'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\InstructorApplicationController::store
 * @see app/Http/Controllers/InstructorApplicationController.php:43
 * @route '/apply-instructor'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/apply-instructor',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorApplicationController::store
 * @see app/Http/Controllers/InstructorApplicationController.php:43
 * @route '/apply-instructor'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorApplicationController::store
 * @see app/Http/Controllers/InstructorApplicationController.php:43
 * @route '/apply-instructor'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorApplicationController::store
 * @see app/Http/Controllers/InstructorApplicationController.php:43
 * @route '/apply-instructor'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorApplicationController::store
 * @see app/Http/Controllers/InstructorApplicationController.php:43
 * @route '/apply-instructor'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const applications = {
    create: Object.assign(create, create),
store: Object.assign(store, store),
}

export default applications