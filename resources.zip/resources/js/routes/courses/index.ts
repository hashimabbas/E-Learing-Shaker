import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults, validateParameters } from './../../wayfinder'
import enroll from './enroll'
/**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/courses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CourseController::index
 * @see app/Http/Controllers/CourseController.php:73
 * @route '/courses'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
export const show = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/courses/{course}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
show.url = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { course: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.slug
                : args.course,
                }

    return show.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
show.get = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
show.head = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
    const showForm = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
        showForm.get = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CourseController::show
 * @see app/Http/Controllers/CourseController.php:109
 * @route '/courses/{course}'
 */
        showForm.head = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
export const preview = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})

preview.definition = {
    methods: ["get","head"],
    url: '/preview/course/{course}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
preview.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return preview.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
preview.get = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: preview.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
preview.head = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: preview.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
    const previewForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: preview.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
        previewForm.get = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SecureVideoController::preview
 * @see app/Http/Controllers/SecureVideoController.php:58
 * @route '/preview/course/{course}'
 */
        previewForm.head = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: preview.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    preview.form = previewForm
/**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
export const learn = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: learn.url(args, options),
    method: 'get',
})

learn.definition = {
    methods: ["get","head"],
    url: '/courses/{course}/learn/{lesson?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
learn.url = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                    lesson: args[1],
                }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
            "lesson",
        ])

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.slug
                : args.course,
                                lesson: args.lesson,
                }

    return learn.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace('{lesson?}', parsedArgs.lesson?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
learn.get = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: learn.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
learn.head = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: learn.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
    const learnForm = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: learn.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
        learnForm.get = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: learn.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CourseController::learn
 * @see app/Http/Controllers/CourseController.php:168
 * @route '/courses/{course}/learn/{lesson?}'
 */
        learnForm.head = (args: { course: string | { slug: string }, lesson?: string | number } | [course: string | { slug: string }, lesson: string | number ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: learn.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    learn.form = learnForm
const courses = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
preview: Object.assign(preview, preview),
enroll: Object.assign(enroll, enroll),
learn: Object.assign(learn, learn),
}

export default courses