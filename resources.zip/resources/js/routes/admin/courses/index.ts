import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\InstructorCourseController::publish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
export const publish = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

publish.definition = {
    methods: ["post"],
    url: '/admin/courses/{course}/toggle-publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::publish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
publish.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return publish.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::publish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
publish.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: publish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::publish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
    const publishForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::publish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
        publishForm.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, options),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/courses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
export const pending = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pending.url(options),
    method: 'get',
})

pending.definition = {
    methods: ["get","head"],
    url: '/admin/courses/pending',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
pending.url = (options?: RouteQueryOptions) => {
    return pending.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
pending.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pending.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
pending.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pending.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
    const pendingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pending.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
        pendingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pending.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::pending
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
        pendingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pending.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pending.form = pendingForm
const courses = {
    publish: Object.assign(publish, publish),
index: Object.assign(index, index),
pending: Object.assign(pending, pending),
}

export default courses