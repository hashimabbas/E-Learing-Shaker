import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\SecurityController::revoke
 * @see app/Http/Controllers/Admin/SecurityController.php:167
 * @route '/admin/security/session/{sessionId}/revoke'
 */
export const revoke = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revoke.url(args, options),
    method: 'post',
})

revoke.definition = {
    methods: ["post"],
    url: '/admin/security/session/{sessionId}/revoke',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::revoke
 * @see app/Http/Controllers/Admin/SecurityController.php:167
 * @route '/admin/security/session/{sessionId}/revoke'
 */
revoke.url = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sessionId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    sessionId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sessionId: args.sessionId,
                }

    return revoke.definition.url
            .replace('{sessionId}', parsedArgs.sessionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::revoke
 * @see app/Http/Controllers/Admin/SecurityController.php:167
 * @route '/admin/security/session/{sessionId}/revoke'
 */
revoke.post = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: revoke.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::revoke
 * @see app/Http/Controllers/Admin/SecurityController.php:167
 * @route '/admin/security/session/{sessionId}/revoke'
 */
    const revokeForm = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: revoke.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::revoke
 * @see app/Http/Controllers/Admin/SecurityController.php:167
 * @route '/admin/security/session/{sessionId}/revoke'
 */
        revokeForm.post = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: revoke.url(args, options),
            method: 'post',
        })
    
    revoke.form = revokeForm
const session = {
    revoke: Object.assign(revoke, revoke),
}

export default session