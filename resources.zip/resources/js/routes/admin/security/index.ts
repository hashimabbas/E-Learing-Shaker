import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import session from './session'
/**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/security',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SecurityController::index
 * @see app/Http/Controllers/Admin/SecurityController.php:71
 * @route '/admin/security'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
export const flagged = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: flagged.url(options),
    method: 'get',
})

flagged.definition = {
    methods: ["get","head"],
    url: '/admin/security/flagged-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
flagged.url = (options?: RouteQueryOptions) => {
    return flagged.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
flagged.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: flagged.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
flagged.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: flagged.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
    const flaggedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: flagged.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
        flaggedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: flagged.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SecurityController::flagged
 * @see app/Http/Controllers/Admin/SecurityController.php:49
 * @route '/admin/security/flagged-users'
 */
        flaggedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: flagged.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    flagged.form = flaggedForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
export const user = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(args, options),
    method: 'get',
})

user.definition = {
    methods: ["get","head"],
    url: '/admin/security/users/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
user.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return user.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
user.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: user.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
user.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: user.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
    const userForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: user.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
        userForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SecurityController::user
 * @see app/Http/Controllers/Admin/SecurityController.php:19
 * @route '/admin/security/users/{user}'
 */
        userForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: user.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    user.form = userForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
export const show = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/security/session/{sessionId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
show.url = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sessionId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    sessionId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sessionId: args.sessionId,
                }

    return show.definition.url
            .replace('{sessionId}', parsedArgs.sessionId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
show.get = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
show.head = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
    const showForm = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
        showForm.get = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\SecurityController::show
 * @see app/Http/Controllers/Admin/SecurityController.php:105
 * @route '/admin/security/session/{sessionId}'
 */
        showForm.head = (args: { sessionId: string | number } | [sessionId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::unflag
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unflag'
 */
export const unflag = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unflag.url(args, options),
    method: 'post',
})

unflag.definition = {
    methods: ["post"],
    url: '/admin/security/{user}/unflag',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::unflag
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unflag'
 */
unflag.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return unflag.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::unflag
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unflag'
 */
unflag.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unflag.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::unflag
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unflag'
 */
    const unflagForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unflag.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::unflag
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unflag'
 */
        unflagForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unflag.url(args, options),
            method: 'post',
        })
    
    unflag.form = unflagForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::forceLogout
 * @see app/Http/Controllers/Admin/SecurityController.php:140
 * @route '/admin/security/{user}/force-logout'
 */
export const forceLogout = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceLogout.url(args, options),
    method: 'post',
})

forceLogout.definition = {
    methods: ["post"],
    url: '/admin/security/{user}/force-logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::forceLogout
 * @see app/Http/Controllers/Admin/SecurityController.php:140
 * @route '/admin/security/{user}/force-logout'
 */
forceLogout.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return forceLogout.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::forceLogout
 * @see app/Http/Controllers/Admin/SecurityController.php:140
 * @route '/admin/security/{user}/force-logout'
 */
forceLogout.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: forceLogout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::forceLogout
 * @see app/Http/Controllers/Admin/SecurityController.php:140
 * @route '/admin/security/{user}/force-logout'
 */
    const forceLogoutForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: forceLogout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::forceLogout
 * @see app/Http/Controllers/Admin/SecurityController.php:140
 * @route '/admin/security/{user}/force-logout'
 */
        forceLogoutForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: forceLogout.url(args, options),
            method: 'post',
        })
    
    forceLogout.form = forceLogoutForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::resetRisk
 * @see app/Http/Controllers/Admin/SecurityController.php:176
 * @route '/admin/security/{user}/reset-risk'
 */
export const resetRisk = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetRisk.url(args, options),
    method: 'post',
})

resetRisk.definition = {
    methods: ["post"],
    url: '/admin/security/{user}/reset-risk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::resetRisk
 * @see app/Http/Controllers/Admin/SecurityController.php:176
 * @route '/admin/security/{user}/reset-risk'
 */
resetRisk.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return resetRisk.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::resetRisk
 * @see app/Http/Controllers/Admin/SecurityController.php:176
 * @route '/admin/security/{user}/reset-risk'
 */
resetRisk.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetRisk.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::resetRisk
 * @see app/Http/Controllers/Admin/SecurityController.php:176
 * @route '/admin/security/{user}/reset-risk'
 */
    const resetRiskForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resetRisk.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::resetRisk
 * @see app/Http/Controllers/Admin/SecurityController.php:176
 * @route '/admin/security/{user}/reset-risk'
 */
        resetRiskForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resetRisk.url(args, options),
            method: 'post',
        })
    
    resetRisk.form = resetRiskForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::note
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/note'
 */
export const note = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: note.url(args, options),
    method: 'post',
})

note.definition = {
    methods: ["post"],
    url: '/admin/security/{user}/note',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::note
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/note'
 */
note.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return note.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::note
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/note'
 */
note.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: note.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::note
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/note'
 */
    const noteForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: note.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::note
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/note'
 */
        noteForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: note.url(args, options),
            method: 'post',
        })
    
    note.form = noteForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::unlock
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unlock'
 */
export const unlock = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unlock.url(args, options),
    method: 'post',
})

unlock.definition = {
    methods: ["post"],
    url: '/admin/security/{user}/unlock',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::unlock
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unlock'
 */
unlock.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return unlock.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::unlock
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unlock'
 */
unlock.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unlock.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::unlock
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unlock'
 */
    const unlockForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unlock.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::unlock
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/unlock'
 */
        unlockForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unlock.url(args, options),
            method: 'post',
        })
    
    unlock.form = unlockForm
/**
* @see \App\Http\Controllers\Admin\SecurityController::ban
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/ban'
 */
export const ban = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ban.url(args, options),
    method: 'post',
})

ban.definition = {
    methods: ["post"],
    url: '/admin/security/{user}/ban',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\SecurityController::ban
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/ban'
 */
ban.url = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: args.user,
                }

    return ban.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\SecurityController::ban
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/ban'
 */
ban.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ban.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\SecurityController::ban
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/ban'
 */
    const banForm = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ban.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\SecurityController::ban
 * @see app/Http/Controllers/Admin/SecurityController.php:0
 * @route '/admin/security/{user}/ban'
 */
        banForm.post = (args: { user: string | number } | [user: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ban.url(args, options),
            method: 'post',
        })
    
    ban.form = banForm
const security = {
    index: Object.assign(index, index),
flagged: Object.assign(flagged, flagged),
user: Object.assign(user, user),
show: Object.assign(show, show),
session: Object.assign(session, session),
unflag: Object.assign(unflag, unflag),
forceLogout: Object.assign(forceLogout, forceLogout),
resetRisk: Object.assign(resetRisk, resetRisk),
note: Object.assign(note, note),
unlock: Object.assign(unlock, unlock),
ban: Object.assign(ban, ban),
}

export default security