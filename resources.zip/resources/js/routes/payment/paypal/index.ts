import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
export const returnMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returnMethod.url(options),
    method: 'get',
})

returnMethod.definition = {
    methods: ["get","head"],
    url: '/checkout/paypal/return',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
returnMethod.url = (options?: RouteQueryOptions) => {
    return returnMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
returnMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: returnMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
returnMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: returnMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
    const returnMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: returnMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
        returnMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: returnMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::returnMethod
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
        returnMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: returnMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    returnMethod.form = returnMethodForm
/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
export const cancel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cancel.url(options),
    method: 'get',
})

cancel.definition = {
    methods: ["get","head"],
    url: '/checkout/paypal/cancel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
cancel.url = (options?: RouteQueryOptions) => {
    return cancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
cancel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cancel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
cancel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cancel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
    const cancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: cancel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
        cancelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cancel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::cancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
        cancelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: cancel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    cancel.form = cancelForm
const paypal = {
    return: Object.assign(returnMethod, returnMethod),
cancel: Object.assign(cancel, cancel),
}

export default paypal