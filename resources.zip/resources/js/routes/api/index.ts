import progress from './progress'
const api = {
    progress: Object.assign(progress, progress),
}

export default api