import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ProgressController::update
 * @see app/Http/Controllers/Api/ProgressController.php:15
 * @route '/progress/update'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/progress/update',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ProgressController::update
 * @see app/Http/Controllers/Api/ProgressController.php:15
 * @route '/progress/update'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ProgressController::update
 * @see app/Http/Controllers/Api/ProgressController.php:15
 * @route '/progress/update'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ProgressController::update
 * @see app/Http/Controllers/Api/ProgressController.php:15
 * @route '/progress/update'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ProgressController::update
 * @see app/Http/Controllers/Api/ProgressController.php:15
 * @route '/progress/update'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const progress = {
    update: Object.assign(update, update),
}

export default progress