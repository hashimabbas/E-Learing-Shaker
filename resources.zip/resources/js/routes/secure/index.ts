import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
export const video = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: video.url(args, options),
    method: 'get',
})

video.definition = {
    methods: ["get","head"],
    url: '/secure/video/{lesson}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
video.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return video.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
video.get = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: video.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
video.head = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: video.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
    const videoForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: video.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
        videoForm.get = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: video.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SecureVideoController::video
 * @see app/Http/Controllers/SecureVideoController.php:15
 * @route '/secure/video/{lesson}'
 */
        videoForm.head = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: video.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    video.form = videoForm
const secure = {
    video: Object.assign(video, video),
}

export default secure