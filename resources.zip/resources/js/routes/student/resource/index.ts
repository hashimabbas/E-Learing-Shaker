import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
export const serve = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serve.url(args, options),
    method: 'get',
})

serve.definition = {
    methods: ["get","head"],
    url: '/protected/serve/{filePath}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
serve.url = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { filePath: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    filePath: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        filePath: args.filePath,
                }

    return serve.definition.url
            .replace('{filePath}', parsedArgs.filePath.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
serve.get = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serve.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
serve.head = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serve.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
    const serveForm = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: serve.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
        serveForm.get = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: serve.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::serve
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
        serveForm.head = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: serve.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    serve.form = serveForm
const resource = {
    serve: Object.assign(serve, serve),
}

export default resource