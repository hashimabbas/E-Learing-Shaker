import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import ebook from './ebook'
import resource from './resource'
import certificate from './certificate'
/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
export const resumeCourse = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resumeCourse.url(args, options),
    method: 'get',
})

resumeCourse.definition = {
    methods: ["get","head"],
    url: '/my-learning/resume/{course}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
resumeCourse.url = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { course: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.slug
                : args.course,
                }

    return resumeCourse.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
resumeCourse.get = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resumeCourse.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
resumeCourse.head = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resumeCourse.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
    const resumeCourseForm = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: resumeCourse.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
        resumeCourseForm.get = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resumeCourse.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
        resumeCourseForm.head = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resumeCourse.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    resumeCourse.form = resumeCourseForm
/**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
export const learning = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: learning.url(options),
    method: 'get',
})

learning.definition = {
    methods: ["get","head"],
    url: '/my-learning',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
learning.url = (options?: RouteQueryOptions) => {
    return learning.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
learning.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: learning.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
learning.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: learning.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
    const learningForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: learning.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
        learningForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: learning.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::learning
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
        learningForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: learning.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    learning.form = learningForm
const student = {
    resumeCourse: Object.assign(resumeCourse, resumeCourse),
ebook: Object.assign(ebook, ebook),
resource: Object.assign(resource, resource),
certificate: Object.assign(certificate, certificate),
learning: Object.assign(learning, learning),
}

export default student