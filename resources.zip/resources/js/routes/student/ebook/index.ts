import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentController::download
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
export const download = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: download.url(args, options),
    method: 'post',
})

download.definition = {
    methods: ["post"],
    url: '/lesson/{lesson}/download',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentController::download
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
download.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return download.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::download
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
download.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: download.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentController::download
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
    const downloadForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: download.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentController::download
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
        downloadForm.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: download.url(args, options),
            method: 'post',
        })
    
    download.form = downloadForm
const ebook = {
    download: Object.assign(download, download),
}

export default ebook