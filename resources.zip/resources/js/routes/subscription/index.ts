import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
export const cancel = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/settings/subscription/{subscription}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
cancel.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return cancel.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
cancel.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
    const cancelForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
        cancelForm.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
export const purchase = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: purchase.url(options),
    method: 'get',
})

purchase.definition = {
    methods: ["get","head"],
    url: '/subscribe',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
purchase.url = (options?: RouteQueryOptions) => {
    return purchase.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
purchase.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: purchase.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
purchase.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: purchase.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
    const purchaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: purchase.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
        purchaseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: purchase.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
        purchaseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: purchase.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    purchase.form = purchaseForm
/**
* @see \App\Http\Controllers\SubscriptionController::initiate
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
export const initiate = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiate.url(args, options),
    method: 'post',
})

initiate.definition = {
    methods: ["post"],
    url: '/subscribe/initiate/{planId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::initiate
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
initiate.url = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { planId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    planId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        planId: args.planId,
                }

    return initiate.definition.url
            .replace('{planId}', parsedArgs.planId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::initiate
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
initiate.post = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::initiate
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
    const initiateForm = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: initiate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::initiate
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
        initiateForm.post = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: initiate.url(args, options),
            method: 'post',
        })
    
    initiate.form = initiateForm
/**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
export const success = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(args, options),
    method: 'get',
})

success.definition = {
    methods: ["get","head"],
    url: '/subscribe/success/{planId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
success.url = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { planId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    planId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        planId: args.planId,
                }

    return success.definition.url
            .replace('{planId}', parsedArgs.planId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
success.get = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
success.head = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: success.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
    const successForm = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: success.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
        successForm.get = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: success.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::success
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
        successForm.head = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: success.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    success.form = successForm
const subscription = {
    index: Object.assign(index, index),
cancel: Object.assign(cancel, cancel),
purchase: Object.assign(purchase, purchase),
initiate: Object.assign(initiate, initiate),
success: Object.assign(success, success),
}

export default subscription