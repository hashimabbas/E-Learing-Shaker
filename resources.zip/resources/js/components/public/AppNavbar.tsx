// resources/js/components/public/AppNavbar.tsx (FINAL VERSION)
import { Link, usePage } from '@inertiajs/react';
import { Button } from '@/components/ui/button';
import { GraduationCap, Menu } from 'lucide-react';
import { dashboard, login, register } from '@/routes';
import { type SharedData } from '@/types';
import { route } from 'ziggy-js';
import { useState } from 'react';

// --- NEW IMPORTS ---
import { NotificationBell } from '@/components/notification-bell';
import { LanguageSwitcher } from '@/components/language-switcher';
import {
    Sheet,
    SheetContent,
    SheetHeader,
    SheetTitle,
    SheetTrigger,
} from '@/components/ui/sheet';
// -------------------

interface AppNavbarProps {
    canRegister: boolean;
}

export default function AppNavbar({ canRegister }: AppNavbarProps) {
    const { auth, translations, locale } = (usePage().props as unknown) as SharedData & { translations: any, locale: string };
    const isRtl = locale === 'ar';
    const [open, setOpen] = useState(false);

    const navItems = [
        { name: translations.home || 'Home', href: route('welcome') },
        { name: translations.nav_portfolio || 'Portfolio', href: route('portfolio') },
        { name: translations.nav_about || 'About Me', href: route('about') },
    ];

    return (
        <header
            className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-black/10"
            dir={isRtl ? 'rtl' : 'ltr'}
        >
            <div className="absolute inset-0  dark:bg-black/70 backdrop-blur-md -z-10" style={{ backgroundColor: '#efe5dc' }} />

            <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 h-16 md:h-20 flex items-center justify-between">
                {/* Mobile Menu Trigger */}
                <div className="flex md:hidden items-center gap-2">
                    <Sheet open={open} onOpenChange={setOpen}>
                        <SheetTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-10 w-10 rounded-xl text-[#3e3838] hover:bg-black/5">
                                <Menu className="size-6" />
                            </Button>
                        </SheetTrigger>
                        <SheetContent
                            side={isRtl ? "right" : "left"}
                            dir={isRtl ? "rtl" : "ltr"}
                            className="!w-full sm:!max-w-[300px] sm:!w-[300px] h-full min-h-[100dvh] max-h-[100dvh] p-0 flex flex-col overflow-hidden bg-background/95 backdrop-blur-xl gap-0 rtl:[&>button]:left-4 rtl:[&>button]:right-auto"
                        >
                            <SheetHeader className="shrink-0 p-6 pb-4 border-b border-border/50 text-left rtl:text-right">
                                <SheetTitle className="font-black text-xl tracking-tight pr-10">
                                    {translations.navbar_logo_text || "Shaker Shams"}
                                </SheetTitle>
                            </SheetHeader>
                            <div className="flex-1 min-h-0 overflow-y-auto flex flex-col gap-2 p-4 pt-6">
                                {navItems.map((item) => (
                                    <Link
                                        key={item.href}
                                        href={item.href}
                                        onClick={() => setOpen(false)}
                                        className="flex items-center px-4 py-4 text-base font-bold text-foreground/80 hover:text-primary hover:bg-primary/5 rounded-2xl transition-all"
                                    >
                                        {item.name}
                                    </Link>
                                ))}
                            </div>
                            <div className="shrink-0 w-full min-w-0 p-4 pt-4 pb-[max(1rem,env(safe-area-inset-bottom))] border-t border-border/50 bg-muted/30 ">
                                {!auth.user ? (
                                    <div className="flex flex-col gap-3 w-full min-w-0">
                                        <Link href={login().url} onClick={() => setOpen(false)} className="w-full min-w-0">
                                            <Button className="w-full min-w-0 h-12 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-600 to-amber-700 font-bold text-black border-none hover:brightness-110 shadow-lg shadow-amber-500/30 transition-all hover:scale-105">
                                                {translations.nav_login || "Log In"}
                                            </Button>
                                        </Link>
                                        {canRegister && (
                                            <Link href={register().url} onClick={() => setOpen(false)} className="w-full min-w-0">
                                                <Button className="w-full min-w-0 h-12 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-600 to-amber-700 font-bold text-black border-none hover:brightness-110 shadow-lg shadow-amber-500/30 transition-all hover:scale-105">
                                                    {translations.nav_signup || "Sign Up"}
                                                </Button>
                                            </Link>
                                        )}
                                    </div>
                                ) : (
                                    <Link href={dashboard().url} onClick={() => setOpen(false)} className="w-full min-w-0 block">
                                        <Button className="w-full min-w-0 h-12 rounded-xl font-black ">
                                            {translations.nav_dashboard || "Go to Dashboard"}
                                        </Button>
                                    </Link>
                                )}
                            </div>
                        </SheetContent>
                    </Sheet>
                    <LanguageSwitcher />
                </div>

                {/* Logo and Workshop Name */}
                <Link href="/" className="hidden md:flex items-center gap-3 group">
                    <div className="flex flex-col">
                        <span className="text-base md:text-lg font-black tracking-tight leading-tight group-hover:text-primary transition-colors text-[#3e3838]">
                            {translations.navbar_logo_text || "Shaker Shams Engineering Workshop"}
                        </span>
                        {/* <span className="text-[9px] md:text-[10px] uppercase tracking-[0.2em] font-bold text-[#3e3838]/60">
                            {isRtl ? "ورشة تعليمية متكاملة" : "Integrated Educational Workshop"}
                        </span> */}
                    </div>
                </Link>

                {/* Desktop Navigation */}
                <nav className="hidden md:flex items-center gap-8">
                    {navItems.map(item => (
                        <Link
                            key={item.href}
                            href={item.href}
                            className="text-sm font-bold text-[#3e3838]/80 hover:text-primary transition-all relative py-2 group"
                        >
                            {item.name}
                            <span className="absolute bottom-0 text-[#3e3838]/80 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full" />
                        </Link>
                    ))}
                </nav>

                {/* Right Side Actions */}
                <div className="flex items-center gap-2 md:gap-4">
                    <div className="hidden md:flex items-center text-[#3e3838]/80 gap-4" >
                        <LanguageSwitcher />
                        <div className="h-6 w-px bg-black/10 mx-2" />
                    </div>

                    {auth.user ? (
                        <div className="flex items-center gap-3 md:gap-4 text-[#3e3838]/80">
                            <NotificationBell />
                            <Link href={dashboard().url}>
                                <Button
                                    variant="default"
                                    size="sm"
                                    className="rounded-xl font-black h-9 md:h-11 px-4 md:px-6 hover:scale-105 transition-transform"

                                >
                                    <span className="hidden sm:inline" >{translations.nav_dashboard || "Dashboard"}</span>
                                    <span className="sm:hidden" >{isRtl ? "الرئيسية" : "Dash"}</span>
                                </Button>
                            </Link>
                        </div>
                    ) : (
                        <div className="hidden md:flex items-center gap-2">
                            <Link href={login().url}>
                                <Button size="sm" className="font-bold rounded-2xl px-6 h-11 bg-gradient-to-r from-amber-400 via-amber-600 to-amber-700 text-black border-none hover:brightness-110 shadow-lg shadow-amber-500/30 transition-all hover:scale-105">
                                    {translations.nav_login || "Log In"}
                                </Button>
                            </Link>
                            {canRegister && (
                                <Link href={register().url}>
                                    <Button size="sm" className="font-bold rounded-2xl px-6 h-11 bg-gradient-to-r from-amber-400 via-amber-600 to-amber-700 text-black border-none hover:brightness-110 shadow-lg shadow-amber-500/30 transition-all hover:scale-105">
                                        {translations.nav_signup || "Sign Up"}
                                    </Button>
                                </Link>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </header>
    );
}
