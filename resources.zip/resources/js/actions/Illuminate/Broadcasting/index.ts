import BroadcastController from './BroadcastController'
const Broadcasting = {
    BroadcastController: Object.assign(BroadcastController, BroadcastController),
}

export default Broadcasting