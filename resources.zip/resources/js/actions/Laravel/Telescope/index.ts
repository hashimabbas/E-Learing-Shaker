import Http from './Http'
const Telescope = {
    Http: Object.assign(Http, Http),
}

export default Telescope