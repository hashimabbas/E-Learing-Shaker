import Fortify from './Fortify'
import Telescope from './Telescope'
const Laravel = {
    Fortify: Object.assign(Fortify, Fortify),
Telescope: Object.assign(Telescope, Telescope),
}

export default Laravel