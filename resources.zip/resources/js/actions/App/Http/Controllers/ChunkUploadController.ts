import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ChunkUploadController::uploadChunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
export const uploadChunk = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadChunk.url(options),
    method: 'post',
})

uploadChunk.definition = {
    methods: ["post"],
    url: '/instructor/upload-chunk',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::uploadChunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
uploadChunk.url = (options?: RouteQueryOptions) => {
    return uploadChunk.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::uploadChunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
uploadChunk.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadChunk.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::uploadChunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
    const uploadChunkForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadChunk.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::uploadChunk
 * @see app/Http/Controllers/ChunkUploadController.php:24
 * @route '/instructor/upload-chunk'
 */
        uploadChunkForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadChunk.url(options),
            method: 'post',
        })
    
    uploadChunk.form = uploadChunkForm
/**
* @see \App\Http\Controllers\ChunkUploadController::finishUpload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
export const finishUpload = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finishUpload.url(args, options),
    method: 'post',
})

finishUpload.definition = {
    methods: ["post"],
    url: '/instructor/lessons/{lesson}/finish-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::finishUpload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
finishUpload.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return finishUpload.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::finishUpload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
finishUpload.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finishUpload.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::finishUpload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
    const finishUploadForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: finishUpload.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::finishUpload
 * @see app/Http/Controllers/ChunkUploadController.php:49
 * @route '/instructor/lessons/{lesson}/finish-upload'
 */
        finishUploadForm.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: finishUpload.url(args, options),
            method: 'post',
        })
    
    finishUpload.form = finishUploadForm
/**
* @see \App\Http\Controllers\ChunkUploadController::finishCoursePreviewUpload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
export const finishCoursePreviewUpload = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finishCoursePreviewUpload.url(args, options),
    method: 'post',
})

finishCoursePreviewUpload.definition = {
    methods: ["post"],
    url: '/instructor/courses/{course}/finish-preview-upload',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ChunkUploadController::finishCoursePreviewUpload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
finishCoursePreviewUpload.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return finishCoursePreviewUpload.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ChunkUploadController::finishCoursePreviewUpload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
finishCoursePreviewUpload.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: finishCoursePreviewUpload.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ChunkUploadController::finishCoursePreviewUpload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
    const finishCoursePreviewUploadForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: finishCoursePreviewUpload.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ChunkUploadController::finishCoursePreviewUpload
 * @see app/Http/Controllers/ChunkUploadController.php:134
 * @route '/instructor/courses/{course}/finish-preview-upload'
 */
        finishCoursePreviewUploadForm.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: finishCoursePreviewUpload.url(args, options),
            method: 'post',
        })
    
    finishCoursePreviewUpload.form = finishCoursePreviewUploadForm
const ChunkUploadController = { uploadChunk, finishUpload, finishCoursePreviewUpload }

export default ChunkUploadController