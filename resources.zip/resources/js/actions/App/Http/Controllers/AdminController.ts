import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::index
 * @see app/Http/Controllers/AdminController.php:26
 * @route '/admin/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
export const pendingCourses = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingCourses.url(options),
    method: 'get',
})

pendingCourses.definition = {
    methods: ["get","head"],
    url: '/admin/courses/pending',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
pendingCourses.url = (options?: RouteQueryOptions) => {
    return pendingCourses.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
pendingCourses.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendingCourses.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
pendingCourses.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pendingCourses.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
    const pendingCoursesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: pendingCourses.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
        pendingCoursesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pendingCourses.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::pendingCourses
 * @see app/Http/Controllers/AdminController.php:53
 * @route '/admin/courses/pending'
 */
        pendingCoursesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: pendingCourses.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    pendingCourses.form = pendingCoursesForm
/**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
export const financialReports = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: financialReports.url(options),
    method: 'get',
})

financialReports.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
financialReports.url = (options?: RouteQueryOptions) => {
    return financialReports.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
financialReports.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: financialReports.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
financialReports.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: financialReports.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
    const financialReportsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: financialReports.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
        financialReportsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: financialReports.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AdminController::financialReports
 * @see app/Http/Controllers/AdminController.php:71
 * @route '/admin/reports'
 */
        financialReportsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: financialReports.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    financialReports.form = financialReportsForm
const AdminController = { index, pendingCourses, financialReports }

export default AdminController