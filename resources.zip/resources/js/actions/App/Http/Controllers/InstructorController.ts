import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/instructor/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorController::index
 * @see app/Http/Controllers/InstructorController.php:25
 * @route '/instructor/dashboard'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
export const sales = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales.url(options),
    method: 'get',
})

sales.definition = {
    methods: ["get","head"],
    url: '/instructor/sales',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
sales.url = (options?: RouteQueryOptions) => {
    return sales.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
sales.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sales.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
sales.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sales.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
    const salesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: sales.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
        salesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sales.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorController::sales
 * @see app/Http/Controllers/InstructorController.php:86
 * @route '/instructor/sales'
 */
        salesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: sales.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    sales.form = salesForm
/**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
export const discussions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: discussions.url(options),
    method: 'get',
})

discussions.definition = {
    methods: ["get","head"],
    url: '/instructor/discussions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
discussions.url = (options?: RouteQueryOptions) => {
    return discussions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
discussions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: discussions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
discussions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: discussions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
    const discussionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: discussions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
        discussionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: discussions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorController::discussions
 * @see app/Http/Controllers/InstructorController.php:111
 * @route '/instructor/discussions'
 */
        discussionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: discussions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    discussions.form = discussionsForm
const InstructorController = { index, sales, discussions }

export default InstructorController