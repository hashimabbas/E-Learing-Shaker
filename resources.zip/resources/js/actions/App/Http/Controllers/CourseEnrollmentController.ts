import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CourseEnrollmentController::enrollFree
 * @see app/Http/Controllers/CourseEnrollmentController.php:12
 * @route '/courses/{course}/enroll-free'
 */
export const enrollFree = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enrollFree.url(args, options),
    method: 'post',
})

enrollFree.definition = {
    methods: ["post"],
    url: '/courses/{course}/enroll-free',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CourseEnrollmentController::enrollFree
 * @see app/Http/Controllers/CourseEnrollmentController.php:12
 * @route '/courses/{course}/enroll-free'
 */
enrollFree.url = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { course: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.slug
                : args.course,
                }

    return enrollFree.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CourseEnrollmentController::enrollFree
 * @see app/Http/Controllers/CourseEnrollmentController.php:12
 * @route '/courses/{course}/enroll-free'
 */
enrollFree.post = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enrollFree.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CourseEnrollmentController::enrollFree
 * @see app/Http/Controllers/CourseEnrollmentController.php:12
 * @route '/courses/{course}/enroll-free'
 */
    const enrollFreeForm = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: enrollFree.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CourseEnrollmentController::enrollFree
 * @see app/Http/Controllers/CourseEnrollmentController.php:12
 * @route '/courses/{course}/enroll-free'
 */
        enrollFreeForm.post = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: enrollFree.url(args, options),
            method: 'post',
        })
    
    enrollFree.form = enrollFreeForm
const CourseEnrollmentController = { enrollFree }

export default CourseEnrollmentController