import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
export const about = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})

about.definition = {
    methods: ["get","head"],
    url: '/about',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
about.url = (options?: RouteQueryOptions) => {
    return about.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
about.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: about.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
about.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: about.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
    const aboutForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: about.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
        aboutForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: about.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SupportController::about
 * @see app/Http/Controllers/SupportController.php:18
 * @route '/about'
 */
        aboutForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: about.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    about.form = aboutForm
/**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
export const portfolio = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: portfolio.url(options),
    method: 'get',
})

portfolio.definition = {
    methods: ["get","head"],
    url: '/portfolio',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
portfolio.url = (options?: RouteQueryOptions) => {
    return portfolio.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
portfolio.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: portfolio.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
portfolio.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: portfolio.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
    const portfolioForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: portfolio.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
        portfolioForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: portfolio.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SupportController::portfolio
 * @see app/Http/Controllers/SupportController.php:23
 * @route '/portfolio'
 */
        portfolioForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: portfolio.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    portfolio.form = portfolioForm
/**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
export const faq = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faq.url(options),
    method: 'get',
})

faq.definition = {
    methods: ["get","head"],
    url: '/faq',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
faq.url = (options?: RouteQueryOptions) => {
    return faq.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
faq.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: faq.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
faq.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: faq.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
    const faqForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: faq.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
        faqForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faq.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SupportController::faq
 * @see app/Http/Controllers/SupportController.php:56
 * @route '/faq'
 */
        faqForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: faq.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    faq.form = faqForm
/**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
export const privacy = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: privacy.url(options),
    method: 'get',
})

privacy.definition = {
    methods: ["get","head"],
    url: '/privacy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
privacy.url = (options?: RouteQueryOptions) => {
    return privacy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
privacy.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: privacy.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
privacy.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: privacy.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
    const privacyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: privacy.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
        privacyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: privacy.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SupportController::privacy
 * @see app/Http/Controllers/SupportController.php:46
 * @route '/privacy'
 */
        privacyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: privacy.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    privacy.form = privacyForm
/**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
export const terms = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terms.url(options),
    method: 'get',
})

terms.definition = {
    methods: ["get","head"],
    url: '/terms-of-use',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
terms.url = (options?: RouteQueryOptions) => {
    return terms.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
terms.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terms.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
terms.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: terms.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
    const termsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: terms.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
        termsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: terms.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SupportController::terms
 * @see app/Http/Controllers/SupportController.php:51
 * @route '/terms-of-use'
 */
        termsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: terms.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    terms.form = termsForm
/**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
export const contact = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})

contact.definition = {
    methods: ["get","head"],
    url: '/contact',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
contact.url = (options?: RouteQueryOptions) => {
    return contact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
contact.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: contact.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
contact.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: contact.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
    const contactForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: contact.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
        contactForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SupportController::contact
 * @see app/Http/Controllers/SupportController.php:68
 * @route '/contact'
 */
        contactForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: contact.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    contact.form = contactForm
/**
* @see \App\Http\Controllers\SupportController::submitContact
 * @see app/Http/Controllers/SupportController.php:76
 * @route '/contact'
 */
export const submitContact = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitContact.url(options),
    method: 'post',
})

submitContact.definition = {
    methods: ["post"],
    url: '/contact',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SupportController::submitContact
 * @see app/Http/Controllers/SupportController.php:76
 * @route '/contact'
 */
submitContact.url = (options?: RouteQueryOptions) => {
    return submitContact.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SupportController::submitContact
 * @see app/Http/Controllers/SupportController.php:76
 * @route '/contact'
 */
submitContact.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submitContact.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SupportController::submitContact
 * @see app/Http/Controllers/SupportController.php:76
 * @route '/contact'
 */
    const submitContactForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submitContact.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SupportController::submitContact
 * @see app/Http/Controllers/SupportController.php:76
 * @route '/contact'
 */
        submitContactForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submitContact.url(options),
            method: 'post',
        })
    
    submitContact.form = submitContactForm
const SupportController = { about, portfolio, faq, privacy, terms, contact, submitContact }

export default SupportController