import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InstructorQuizController::store
 * @see app/Http/Controllers/InstructorQuizController.php:43
 * @route '/instructor/quizzes'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/instructor/quizzes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorQuizController::store
 * @see app/Http/Controllers/InstructorQuizController.php:43
 * @route '/instructor/quizzes'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorQuizController::store
 * @see app/Http/Controllers/InstructorQuizController.php:43
 * @route '/instructor/quizzes'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorQuizController::store
 * @see app/Http/Controllers/InstructorQuizController.php:43
 * @route '/instructor/quizzes'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorQuizController::store
 * @see app/Http/Controllers/InstructorQuizController.php:43
 * @route '/instructor/quizzes'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\InstructorQuizController::addQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:62
 * @route '/instructor/quizzes/{quiz}/question'
 */
export const addQuestion = (args: { quiz: number | { id: number } } | [quiz: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addQuestion.url(args, options),
    method: 'post',
})

addQuestion.definition = {
    methods: ["post"],
    url: '/instructor/quizzes/{quiz}/question',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorQuizController::addQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:62
 * @route '/instructor/quizzes/{quiz}/question'
 */
addQuestion.url = (args: { quiz: number | { id: number } } | [quiz: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quiz: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { quiz: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quiz: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quiz: typeof args.quiz === 'object'
                ? args.quiz.id
                : args.quiz,
                }

    return addQuestion.definition.url
            .replace('{quiz}', parsedArgs.quiz.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorQuizController::addQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:62
 * @route '/instructor/quizzes/{quiz}/question'
 */
addQuestion.post = (args: { quiz: number | { id: number } } | [quiz: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addQuestion.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorQuizController::addQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:62
 * @route '/instructor/quizzes/{quiz}/question'
 */
    const addQuestionForm = (args: { quiz: number | { id: number } } | [quiz: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addQuestion.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorQuizController::addQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:62
 * @route '/instructor/quizzes/{quiz}/question'
 */
        addQuestionForm.post = (args: { quiz: number | { id: number } } | [quiz: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addQuestion.url(args, options),
            method: 'post',
        })
    
    addQuestion.form = addQuestionForm
/**
* @see \App\Http\Controllers\InstructorQuizController::updateQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:106
 * @route '/instructor/quizzes/{question}/question'
 */
export const updateQuestion = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateQuestion.url(args, options),
    method: 'put',
})

updateQuestion.definition = {
    methods: ["put"],
    url: '/instructor/quizzes/{question}/question',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\InstructorQuizController::updateQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:106
 * @route '/instructor/quizzes/{question}/question'
 */
updateQuestion.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return updateQuestion.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorQuizController::updateQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:106
 * @route '/instructor/quizzes/{question}/question'
 */
updateQuestion.put = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateQuestion.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\InstructorQuizController::updateQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:106
 * @route '/instructor/quizzes/{question}/question'
 */
    const updateQuestionForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateQuestion.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorQuizController::updateQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:106
 * @route '/instructor/quizzes/{question}/question'
 */
        updateQuestionForm.put = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateQuestion.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateQuestion.form = updateQuestionForm
/**
* @see \App\Http\Controllers\InstructorQuizController::destroyQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:151
 * @route '/instructor/quizzes/{question}/question'
 */
export const destroyQuestion = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

destroyQuestion.definition = {
    methods: ["delete"],
    url: '/instructor/quizzes/{question}/question',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\InstructorQuizController::destroyQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:151
 * @route '/instructor/quizzes/{question}/question'
 */
destroyQuestion.url = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { question: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { question: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    question: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        question: typeof args.question === 'object'
                ? args.question.id
                : args.question,
                }

    return destroyQuestion.definition.url
            .replace('{question}', parsedArgs.question.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorQuizController::destroyQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:151
 * @route '/instructor/quizzes/{question}/question'
 */
destroyQuestion.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyQuestion.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\InstructorQuizController::destroyQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:151
 * @route '/instructor/quizzes/{question}/question'
 */
    const destroyQuestionForm = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyQuestion.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorQuizController::destroyQuestion
 * @see app/Http/Controllers/InstructorQuizController.php:151
 * @route '/instructor/quizzes/{question}/question'
 */
        destroyQuestionForm.delete = (args: { question: number | { id: number } } | [question: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyQuestion.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyQuestion.form = destroyQuestionForm
const InstructorQuizController = { store, addQuestion, updateQuestion, destroyQuestion }

export default InstructorQuizController