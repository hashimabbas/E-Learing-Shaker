import ProgressController from './ProgressController'
const Api = {
    ProgressController: Object.assign(ProgressController, ProgressController),
}

export default Api