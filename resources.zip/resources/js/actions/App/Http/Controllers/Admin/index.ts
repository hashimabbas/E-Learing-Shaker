import SecurityController from './SecurityController'
import PaymentController from './PaymentController'
const Admin = {
    SecurityController: Object.assign(SecurityController, SecurityController),
PaymentController: Object.assign(PaymentController, PaymentController),
}

export default Admin