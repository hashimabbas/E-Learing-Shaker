import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PaymentController::initiatePayment
 * @see app/Http/Controllers/PaymentController.php:37
 * @route '/checkout/initiate'
 */
export const initiatePayment = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiatePayment.url(options),
    method: 'post',
})

initiatePayment.definition = {
    methods: ["post"],
    url: '/checkout/initiate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PaymentController::initiatePayment
 * @see app/Http/Controllers/PaymentController.php:37
 * @route '/checkout/initiate'
 */
initiatePayment.url = (options?: RouteQueryOptions) => {
    return initiatePayment.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::initiatePayment
 * @see app/Http/Controllers/PaymentController.php:37
 * @route '/checkout/initiate'
 */
initiatePayment.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiatePayment.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PaymentController::initiatePayment
 * @see app/Http/Controllers/PaymentController.php:37
 * @route '/checkout/initiate'
 */
    const initiatePaymentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: initiatePayment.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PaymentController::initiatePayment
 * @see app/Http/Controllers/PaymentController.php:37
 * @route '/checkout/initiate'
 */
        initiatePaymentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: initiatePayment.url(options),
            method: 'post',
        })
    
    initiatePayment.form = initiatePaymentForm
/**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
export const paymentSuccess = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentSuccess.url(args, options),
    method: 'get',
})

paymentSuccess.definition = {
    methods: ["get","head"],
    url: '/checkout/success/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
paymentSuccess.url = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'order_number' in args) {
            args = { order: args.order_number }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.order_number
                : args.order,
                }

    return paymentSuccess.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
paymentSuccess.get = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentSuccess.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
paymentSuccess.head = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: paymentSuccess.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
    const paymentSuccessForm = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: paymentSuccess.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
        paymentSuccessForm.get = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paymentSuccess.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::paymentSuccess
 * @see app/Http/Controllers/PaymentController.php:231
 * @route '/checkout/success/{order}'
 */
        paymentSuccessForm.head = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paymentSuccess.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    paymentSuccess.form = paymentSuccessForm
/**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
export const paymentCancel = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentCancel.url(args, options),
    method: 'get',
})

paymentCancel.definition = {
    methods: ["get","head"],
    url: '/checkout/cancel/{order}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
paymentCancel.url = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { order: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'order_number' in args) {
            args = { order: args.order_number }
        }
    
    if (Array.isArray(args)) {
        args = {
                    order: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        order: typeof args.order === 'object'
                ? args.order.order_number
                : args.order,
                }

    return paymentCancel.definition.url
            .replace('{order}', parsedArgs.order.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
paymentCancel.get = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentCancel.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
paymentCancel.head = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: paymentCancel.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
    const paymentCancelForm = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: paymentCancel.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
        paymentCancelForm.get = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paymentCancel.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::paymentCancel
 * @see app/Http/Controllers/PaymentController.php:276
 * @route '/checkout/cancel/{order}'
 */
        paymentCancelForm.head = (args: { order: string | number | { order_number: string | number } } | [order: string | number | { order_number: string | number } ] | string | number | { order_number: string | number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paymentCancel.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    paymentCancel.form = paymentCancelForm
/**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
export const paypalReturn = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paypalReturn.url(options),
    method: 'get',
})

paypalReturn.definition = {
    methods: ["get","head"],
    url: '/checkout/paypal/return',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
paypalReturn.url = (options?: RouteQueryOptions) => {
    return paypalReturn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
paypalReturn.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paypalReturn.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
paypalReturn.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: paypalReturn.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
    const paypalReturnForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: paypalReturn.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
        paypalReturnForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paypalReturn.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::paypalReturn
 * @see app/Http/Controllers/PaymentController.php:136
 * @route '/checkout/paypal/return'
 */
        paypalReturnForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paypalReturn.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    paypalReturn.form = paypalReturnForm
/**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
export const paypalCancel = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paypalCancel.url(options),
    method: 'get',
})

paypalCancel.definition = {
    methods: ["get","head"],
    url: '/checkout/paypal/cancel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
paypalCancel.url = (options?: RouteQueryOptions) => {
    return paypalCancel.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
paypalCancel.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paypalCancel.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
paypalCancel.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: paypalCancel.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
    const paypalCancelForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: paypalCancel.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
        paypalCancelForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paypalCancel.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PaymentController::paypalCancel
 * @see app/Http/Controllers/PaymentController.php:223
 * @route '/checkout/paypal/cancel'
 */
        paypalCancelForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paypalCancel.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    paypalCancel.form = paypalCancelForm
const PaymentController = { initiatePayment, paymentSuccess, paymentCancel, paypalReturn, paypalCancel }

export default PaymentController