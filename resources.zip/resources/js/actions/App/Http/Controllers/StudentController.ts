import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
const index42a740574ecbfbac32f8cc353fc32db9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

index42a740574ecbfbac32f8cc353fc32db9.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
index42a740574ecbfbac32f8cc353fc32db9.url = (options?: RouteQueryOptions) => {
    return index42a740574ecbfbac32f8cc353fc32db9.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
index42a740574ecbfbac32f8cc353fc32db9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
index42a740574ecbfbac32f8cc353fc32db9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
    const index42a740574ecbfbac32f8cc353fc32db9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index42a740574ecbfbac32f8cc353fc32db9.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
        index42a740574ecbfbac32f8cc353fc32db9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index42a740574ecbfbac32f8cc353fc32db9.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/dashboard'
 */
        index42a740574ecbfbac32f8cc353fc32db9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index42a740574ecbfbac32f8cc353fc32db9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index42a740574ecbfbac32f8cc353fc32db9.form = index42a740574ecbfbac32f8cc353fc32db9Form
    /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
const index43753603dbde877dfdd70a1d8494eeb8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index43753603dbde877dfdd70a1d8494eeb8.url(options),
    method: 'get',
})

index43753603dbde877dfdd70a1d8494eeb8.definition = {
    methods: ["get","head"],
    url: '/my-learning',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
index43753603dbde877dfdd70a1d8494eeb8.url = (options?: RouteQueryOptions) => {
    return index43753603dbde877dfdd70a1d8494eeb8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
index43753603dbde877dfdd70a1d8494eeb8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index43753603dbde877dfdd70a1d8494eeb8.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
index43753603dbde877dfdd70a1d8494eeb8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index43753603dbde877dfdd70a1d8494eeb8.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
    const index43753603dbde877dfdd70a1d8494eeb8Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index43753603dbde877dfdd70a1d8494eeb8.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
        index43753603dbde877dfdd70a1d8494eeb8Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index43753603dbde877dfdd70a1d8494eeb8.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::index
 * @see app/Http/Controllers/StudentController.php:30
 * @route '/my-learning'
 */
        index43753603dbde877dfdd70a1d8494eeb8Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index43753603dbde877dfdd70a1d8494eeb8.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index43753603dbde877dfdd70a1d8494eeb8.form = index43753603dbde877dfdd70a1d8494eeb8Form

export const index = {
    '/dashboard': index42a740574ecbfbac32f8cc353fc32db9,
    '/my-learning': index43753603dbde877dfdd70a1d8494eeb8,
}

/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
export const resumeCourse = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resumeCourse.url(args, options),
    method: 'get',
})

resumeCourse.definition = {
    methods: ["get","head"],
    url: '/my-learning/resume/{course}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
resumeCourse.url = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'slug' in args) {
            args = { course: args.slug }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.slug
                : args.course,
                }

    return resumeCourse.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
resumeCourse.get = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: resumeCourse.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
resumeCourse.head = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: resumeCourse.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
    const resumeCourseForm = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: resumeCourse.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
        resumeCourseForm.get = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resumeCourse.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::resumeCourse
 * @see app/Http/Controllers/StudentController.php:161
 * @route '/my-learning/resume/{course}'
 */
        resumeCourseForm.head = (args: { course: string | { slug: string } } | [course: string | { slug: string } ] | string | { slug: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: resumeCourse.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    resumeCourse.form = resumeCourseForm
/**
* @see \App\Http\Controllers\StudentController::generateEbookLink
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
export const generateEbookLink = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateEbookLink.url(args, options),
    method: 'post',
})

generateEbookLink.definition = {
    methods: ["post"],
    url: '/lesson/{lesson}/download',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentController::generateEbookLink
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
generateEbookLink.url = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { lesson: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { lesson: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    lesson: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        lesson: typeof args.lesson === 'object'
                ? args.lesson.id
                : args.lesson,
                }

    return generateEbookLink.definition.url
            .replace('{lesson}', parsedArgs.lesson.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::generateEbookLink
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
generateEbookLink.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateEbookLink.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentController::generateEbookLink
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
    const generateEbookLinkForm = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateEbookLink.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentController::generateEbookLink
 * @see app/Http/Controllers/StudentController.php:62
 * @route '/lesson/{lesson}/download'
 */
        generateEbookLinkForm.post = (args: { lesson: number | { id: number } } | [lesson: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateEbookLink.url(args, options),
            method: 'post',
        })
    
    generateEbookLink.form = generateEbookLinkForm
/**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
export const serveProtectedResource = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serveProtectedResource.url(args, options),
    method: 'get',
})

serveProtectedResource.definition = {
    methods: ["get","head"],
    url: '/protected/serve/{filePath}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
serveProtectedResource.url = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { filePath: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    filePath: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        filePath: args.filePath,
                }

    return serveProtectedResource.definition.url
            .replace('{filePath}', parsedArgs.filePath.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
serveProtectedResource.get = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serveProtectedResource.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
serveProtectedResource.head = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serveProtectedResource.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
    const serveProtectedResourceForm = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: serveProtectedResource.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
        serveProtectedResourceForm.get = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: serveProtectedResource.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StudentController::serveProtectedResource
 * @see app/Http/Controllers/StudentController.php:93
 * @route '/protected/serve/{filePath}'
 */
        serveProtectedResourceForm.head = (args: { filePath: string | number } | [filePath: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: serveProtectedResource.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    serveProtectedResource.form = serveProtectedResourceForm
/**
* @see \App\Http\Controllers\StudentController::generateCertificate
 * @see app/Http/Controllers/StudentController.php:115
 * @route '/course/{course}/certificate'
 */
export const generateCertificate = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateCertificate.url(args, options),
    method: 'post',
})

generateCertificate.definition = {
    methods: ["post"],
    url: '/course/{course}/certificate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StudentController::generateCertificate
 * @see app/Http/Controllers/StudentController.php:115
 * @route '/course/{course}/certificate'
 */
generateCertificate.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return generateCertificate.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StudentController::generateCertificate
 * @see app/Http/Controllers/StudentController.php:115
 * @route '/course/{course}/certificate'
 */
generateCertificate.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generateCertificate.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StudentController::generateCertificate
 * @see app/Http/Controllers/StudentController.php:115
 * @route '/course/{course}/certificate'
 */
    const generateCertificateForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generateCertificate.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StudentController::generateCertificate
 * @see app/Http/Controllers/StudentController.php:115
 * @route '/course/{course}/certificate'
 */
        generateCertificateForm.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generateCertificate.url(args, options),
            method: 'post',
        })
    
    generateCertificate.form = generateCertificateForm
const StudentController = { index, resumeCourse, generateEbookLink, serveProtectedResource, generateCertificate }

export default StudentController