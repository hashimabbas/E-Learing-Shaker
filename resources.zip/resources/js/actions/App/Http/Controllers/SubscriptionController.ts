import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/settings/subscription',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::index
 * @see app/Http/Controllers/SubscriptionController.php:24
 * @route '/settings/subscription'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
export const cancel = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/settings/subscription/{subscription}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
cancel.url = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subscription: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subscription: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subscription: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subscription: typeof args.subscription === 'object'
                ? args.subscription.id
                : args.subscription,
                }

    return cancel.definition.url
            .replace('{subscription}', parsedArgs.subscription.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
cancel.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
    const cancelForm = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::cancel
 * @see app/Http/Controllers/SubscriptionController.php:36
 * @route '/settings/subscription/{subscription}/cancel'
 */
        cancelForm.post = (args: { subscription: number | { id: number } } | [subscription: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
export const purchase = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: purchase.url(options),
    method: 'get',
})

purchase.definition = {
    methods: ["get","head"],
    url: '/subscribe',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
purchase.url = (options?: RouteQueryOptions) => {
    return purchase.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
purchase.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: purchase.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
purchase.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: purchase.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
    const purchaseForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: purchase.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
        purchaseForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: purchase.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::purchase
 * @see app/Http/Controllers/SubscriptionController.php:0
 * @route '/subscribe'
 */
        purchaseForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: purchase.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    purchase.form = purchaseForm
/**
* @see \App\Http\Controllers\SubscriptionController::initiateCheckout
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
export const initiateCheckout = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiateCheckout.url(args, options),
    method: 'post',
})

initiateCheckout.definition = {
    methods: ["post"],
    url: '/subscribe/initiate/{planId}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SubscriptionController::initiateCheckout
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
initiateCheckout.url = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { planId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    planId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        planId: args.planId,
                }

    return initiateCheckout.definition.url
            .replace('{planId}', parsedArgs.planId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::initiateCheckout
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
initiateCheckout.post = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: initiateCheckout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::initiateCheckout
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
    const initiateCheckoutForm = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: initiateCheckout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::initiateCheckout
 * @see app/Http/Controllers/SubscriptionController.php:59
 * @route '/subscribe/initiate/{planId}'
 */
        initiateCheckoutForm.post = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: initiateCheckout.url(args, options),
            method: 'post',
        })
    
    initiateCheckout.form = initiateCheckoutForm
/**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
export const successCallback = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: successCallback.url(args, options),
    method: 'get',
})

successCallback.definition = {
    methods: ["get","head"],
    url: '/subscribe/success/{planId}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
successCallback.url = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { planId: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    planId: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        planId: args.planId,
                }

    return successCallback.definition.url
            .replace('{planId}', parsedArgs.planId.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
successCallback.get = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: successCallback.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
successCallback.head = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: successCallback.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
    const successCallbackForm = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: successCallback.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
        successCallbackForm.get = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: successCallback.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SubscriptionController::successCallback
 * @see app/Http/Controllers/SubscriptionController.php:70
 * @route '/subscribe/success/{planId}'
 */
        successCallbackForm.head = (args: { planId: string | number } | [planId: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: successCallback.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    successCallback.form = successCallbackForm
const SubscriptionController = { index, cancel, purchase, initiateCheckout, successCallback }

export default SubscriptionController