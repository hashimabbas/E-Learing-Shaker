import WelcomeController from './WelcomeController'
import LanguageController from './LanguageController'
import CourseController from './CourseController'
import SupportController from './SupportController'
import SecureVideoController from './SecureVideoController'
import CourseEnrollmentController from './CourseEnrollmentController'
import StudentController from './StudentController'
import WishlistController from './WishlistController'
import CartController from './CartController'
import PaymentController from './PaymentController'
import OrderController from './OrderController'
import Api from './Api'
import QuizController from './QuizController'
import DiscussionController from './DiscussionController'
import ReviewController from './ReviewController'
import CertificatesController from './CertificatesController'
import SubscriptionController from './SubscriptionController'
import InstructorApplicationController from './InstructorApplicationController'
import InstructorController from './InstructorController'
import InstructorCourseController from './InstructorCourseController'
import InstructorLessonController from './InstructorLessonController'
import ChunkUploadController from './ChunkUploadController'
import InstructorQuizController from './InstructorQuizController'
import AdminController from './AdminController'
import AdminUserController from './AdminUserController'
import AdminCategoryController from './AdminCategoryController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    WelcomeController: Object.assign(WelcomeController, WelcomeController),
LanguageController: Object.assign(LanguageController, LanguageController),
CourseController: Object.assign(CourseController, CourseController),
SupportController: Object.assign(SupportController, SupportController),
SecureVideoController: Object.assign(SecureVideoController, SecureVideoController),
CourseEnrollmentController: Object.assign(CourseEnrollmentController, CourseEnrollmentController),
StudentController: Object.assign(StudentController, StudentController),
WishlistController: Object.assign(WishlistController, WishlistController),
CartController: Object.assign(CartController, CartController),
PaymentController: Object.assign(PaymentController, PaymentController),
OrderController: Object.assign(OrderController, OrderController),
Api: Object.assign(Api, Api),
QuizController: Object.assign(QuizController, QuizController),
DiscussionController: Object.assign(DiscussionController, DiscussionController),
ReviewController: Object.assign(ReviewController, ReviewController),
CertificatesController: Object.assign(CertificatesController, CertificatesController),
SubscriptionController: Object.assign(SubscriptionController, SubscriptionController),
InstructorApplicationController: Object.assign(InstructorApplicationController, InstructorApplicationController),
InstructorController: Object.assign(InstructorController, InstructorController),
InstructorCourseController: Object.assign(InstructorCourseController, InstructorCourseController),
InstructorLessonController: Object.assign(InstructorLessonController, InstructorLessonController),
ChunkUploadController: Object.assign(ChunkUploadController, ChunkUploadController),
InstructorQuizController: Object.assign(InstructorQuizController, InstructorQuizController),
AdminController: Object.assign(AdminController, AdminController),
AdminUserController: Object.assign(AdminUserController, AdminUserController),
AdminCategoryController: Object.assign(AdminCategoryController, AdminCategoryController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers