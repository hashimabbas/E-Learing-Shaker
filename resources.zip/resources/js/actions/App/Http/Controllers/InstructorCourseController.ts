import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
const index3a3a4f9cdedad372c096b9a34276c0b1 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index3a3a4f9cdedad372c096b9a34276c0b1.url(options),
    method: 'get',
})

index3a3a4f9cdedad372c096b9a34276c0b1.definition = {
    methods: ["get","head"],
    url: '/instructor/courses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
index3a3a4f9cdedad372c096b9a34276c0b1.url = (options?: RouteQueryOptions) => {
    return index3a3a4f9cdedad372c096b9a34276c0b1.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
index3a3a4f9cdedad372c096b9a34276c0b1.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index3a3a4f9cdedad372c096b9a34276c0b1.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
index3a3a4f9cdedad372c096b9a34276c0b1.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index3a3a4f9cdedad372c096b9a34276c0b1.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
    const index3a3a4f9cdedad372c096b9a34276c0b1Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index3a3a4f9cdedad372c096b9a34276c0b1.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
        index3a3a4f9cdedad372c096b9a34276c0b1Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index3a3a4f9cdedad372c096b9a34276c0b1.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/instructor/courses'
 */
        index3a3a4f9cdedad372c096b9a34276c0b1Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index3a3a4f9cdedad372c096b9a34276c0b1.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index3a3a4f9cdedad372c096b9a34276c0b1.form = index3a3a4f9cdedad372c096b9a34276c0b1Form
    /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
const index7ce4cbe62480954a4f6ada55163f4216 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index7ce4cbe62480954a4f6ada55163f4216.url(options),
    method: 'get',
})

index7ce4cbe62480954a4f6ada55163f4216.definition = {
    methods: ["get","head"],
    url: '/admin/courses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
index7ce4cbe62480954a4f6ada55163f4216.url = (options?: RouteQueryOptions) => {
    return index7ce4cbe62480954a4f6ada55163f4216.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
index7ce4cbe62480954a4f6ada55163f4216.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index7ce4cbe62480954a4f6ada55163f4216.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
index7ce4cbe62480954a4f6ada55163f4216.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index7ce4cbe62480954a4f6ada55163f4216.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
    const index7ce4cbe62480954a4f6ada55163f4216Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index7ce4cbe62480954a4f6ada55163f4216.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
        index7ce4cbe62480954a4f6ada55163f4216Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index7ce4cbe62480954a4f6ada55163f4216.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorCourseController::index
 * @see app/Http/Controllers/InstructorCourseController.php:28
 * @route '/admin/courses'
 */
        index7ce4cbe62480954a4f6ada55163f4216Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index7ce4cbe62480954a4f6ada55163f4216.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index7ce4cbe62480954a4f6ada55163f4216.form = index7ce4cbe62480954a4f6ada55163f4216Form

export const index = {
    '/instructor/courses': index3a3a4f9cdedad372c096b9a34276c0b1,
    '/admin/courses': index7ce4cbe62480954a4f6ada55163f4216,
}

/**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/instructor/courses/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorCourseController::create
 * @see app/Http/Controllers/InstructorCourseController.php:52
 * @route '/instructor/courses/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\InstructorCourseController::store
 * @see app/Http/Controllers/InstructorCourseController.php:64
 * @route '/instructor/courses'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/instructor/courses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::store
 * @see app/Http/Controllers/InstructorCourseController.php:64
 * @route '/instructor/courses'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::store
 * @see app/Http/Controllers/InstructorCourseController.php:64
 * @route '/instructor/courses'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::store
 * @see app/Http/Controllers/InstructorCourseController.php:64
 * @route '/instructor/courses'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::store
 * @see app/Http/Controllers/InstructorCourseController.php:64
 * @route '/instructor/courses'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
export const edit = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/instructor/courses/{course}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
edit.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return edit.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
edit.get = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
edit.head = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
    const editForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
        editForm.get = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InstructorCourseController::edit
 * @see app/Http/Controllers/InstructorCourseController.php:104
 * @route '/instructor/courses/{course}/edit'
 */
        editForm.head = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
export const update = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/instructor/courses/{course}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
update.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return update.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
update.put = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
update.patch = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
    const updateForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
        updateForm.put = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\InstructorCourseController::update
 * @see app/Http/Controllers/InstructorCourseController.php:137
 * @route '/instructor/courses/{course}'
 */
        updateForm.patch = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\InstructorCourseController::destroy
 * @see app/Http/Controllers/InstructorCourseController.php:0
 * @route '/instructor/courses/{course}'
 */
export const destroy = (args: { course: string | number } | [course: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/instructor/courses/{course}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::destroy
 * @see app/Http/Controllers/InstructorCourseController.php:0
 * @route '/instructor/courses/{course}'
 */
destroy.url = (args: { course: string | number } | [course: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: args.course,
                }

    return destroy.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::destroy
 * @see app/Http/Controllers/InstructorCourseController.php:0
 * @route '/instructor/courses/{course}'
 */
destroy.delete = (args: { course: string | number } | [course: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::destroy
 * @see app/Http/Controllers/InstructorCourseController.php:0
 * @route '/instructor/courses/{course}'
 */
    const destroyForm = (args: { course: string | number } | [course: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::destroy
 * @see app/Http/Controllers/InstructorCourseController.php:0
 * @route '/instructor/courses/{course}'
 */
        destroyForm.delete = (args: { course: string | number } | [course: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\InstructorCourseController::togglePublish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
export const togglePublish = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: togglePublish.url(args, options),
    method: 'post',
})

togglePublish.definition = {
    methods: ["post"],
    url: '/admin/courses/{course}/toggle-publish',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InstructorCourseController::togglePublish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
togglePublish.url = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { course: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { course: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    course: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        course: typeof args.course === 'object'
                ? args.course.id
                : args.course,
                }

    return togglePublish.definition.url
            .replace('{course}', parsedArgs.course.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InstructorCourseController::togglePublish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
togglePublish.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: togglePublish.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InstructorCourseController::togglePublish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
    const togglePublishForm = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: togglePublish.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InstructorCourseController::togglePublish
 * @see app/Http/Controllers/InstructorCourseController.php:175
 * @route '/admin/courses/{course}/toggle-publish'
 */
        togglePublishForm.post = (args: { course: number | { id: number } } | [course: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: togglePublish.url(args, options),
            method: 'post',
        })
    
    togglePublish.form = togglePublishForm
const InstructorCourseController = { index, create, store, edit, update, destroy, togglePublish }

export default InstructorCourseController